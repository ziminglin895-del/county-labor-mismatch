# -*- coding: utf-8 -*-
"""
任务三 · 第一步：招聘数据清洗、学历编码重建、县级指标构建

输入：任务一成果/任务二成果 中的三份招聘表（河南、浙江、四川）
输出：写入 D:\大创不自信版\任务三成果\
    01_学历编码规则与对照表.xlsx
    02_招聘明细_清洗版.xlsx
    03_县级招聘侧指标.xlsx
    04_分析数据集.xlsx
    05_变量定义与数据说明.xlsx

设计要点：
1. 学历编码一律以"学历要求"原文重新判定，不沿用原表的 0/1 变量与标准分类
   （原表存在分类与原文对不上的问题，详见输出说明）。
2. 招聘人数缺失一律保留缺失，不按 1 人补。
3. 县区归属：浙江、四川的"工作区域"已是县级单位名称；河南的"工作区域"
   是平台原始标签，按"地级市-县" / "县-乡镇" / "其他-县" 三类模式解析。
"""

import re
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(r"D:\大创不自信版")
T3 = ROOT / "任务三成果"
OUT = T3 / "附件"
OUT.mkdir(parents=True, exist_ok=True)

SOURCES = {
    "河南": ROOT / "任务一成果" / "河南省县域招聘数据_清洗交付版.xlsx",
    "浙江": ROOT / "任务二成果" / "浙江.xlsx",
    "四川": ROOT / "任务二成果" / "四川.xlsx",
}

# ---------------------------------------------------------------- 学历编码
# 统一门槛序列（数值越大门槛越高），未注明与学历不限不进入排序
TIER_SCORE = {
    "未注明": np.nan,
    "学历不限": 0.0,
    "初中及以下": 1.0,
    "高中及以上": 2.0,
    "大专及以上": 3.0,
    "本科及以上": 4.0,
    "硕士及以上": 5.0,
}

# 判定顺序：从高门槛往低门槛，避免"本科及以上"被"大专"误命中
HIGH_TO_LOW = [
    ("硕士及以上", ("博士", "硕士", "研究生", "mba", "emba")),
    ("本科及以上", ("本科", "学士")),
    ("大专及以上", ("大专", "专科", "高职", "大学")),
    ("高中及以上", ("中专", "中技", "技校", "职高", "高中")),
    ("初中及以下", ("初中", "小学")),
]

NO_RESTRICTION = ("不限", "无要求", "无学历要求")
MISSING_TOKENS = {"", "nan", "none", "null", "未注明", "未知", "无"}


def classify_education(raw) -> str:
    """把学历要求原文映射到统一门槛标签。无法识别的一律记为未注明。"""
    if raw is None or (isinstance(raw, float) and np.isnan(raw)):
        return "未注明"
    text = str(raw).strip().lower().replace(" ", "")
    if text in MISSING_TOKENS:
        return "未注明"
    for label, keys in HIGH_TO_LOW:
        if any(k in text for k in keys):
            return label
    if any(k in text for k in NO_RESTRICTION):
        return "学历不限"
    return "未注明"


# ---------------------------------------------------------------- 招聘人数
def parse_headcount(raw):
    """把 '1人' / '10人' / 12 解析为数值；无法解析返回 NaN（不默认为 1）。"""
    if raw is None or (isinstance(raw, float) and np.isnan(raw)):
        return np.nan
    text = str(raw).strip()
    if text.lower() in {"", "nan", "none", "若干", "若干人", "不限", "多人"}:
        return np.nan
    hit = re.search(r"(\d+(?:\.\d+)?)", text)
    return float(hit.group(1)) if hit else np.nan


# ---------------------------------------------------------------- 县区解析
HN_CITIES = [
    "郑州", "开封", "洛阳", "平顶山", "安阳", "鹤壁", "新乡", "焦作", "濮阳",
    "许昌", "漯河", "三门峡", "南阳", "商丘", "信阳", "周口", "驻马店", "济源",
]
NON_COUNTY = {"其他", "其它", "其他区域", "周边", "城区", "无", "不限"}
# 河南省县级行政区白名单（用于剔除平台标签里的乡镇、商圈名）
HN_COUNTIES = [
    "中牟县", "巩义市", "荥阳市", "新密市", "新郑市", "登封市",
    "杞县", "通许县", "尉氏县", "兰考县",
    "新安县", "栾川县", "嵩县", "汝阳县", "宜阳县", "洛宁县", "伊川县",
    "宝丰县", "叶县", "鲁山县", "郏县", "舞钢市", "汝州市",
    "安阳县", "汤阴县", "滑县", "内黄县", "林州市",
    "浚县", "淇县",
    "新乡县", "获嘉县", "原阳县", "延津县", "封丘县", "长垣市", "卫辉市", "辉县市",
    "修武县", "博爱县", "武陟县", "温县", "沁阳市", "孟州市",
    "清丰县", "南乐县", "范县", "台前县", "濮阳县",
    "鄢陵县", "襄城县", "禹州市", "长葛市",
    "舞阳县", "临颍县",
    "渑池县", "卢氏县", "义马市", "灵宝市",
    "南召县", "方城县", "西峡县", "镇平县", "内乡县", "淅川县", "社旗县",
    "唐河县", "新野县", "桐柏县", "邓州市",
    "民权县", "睢县", "宁陵县", "柘城县", "虞城县", "夏邑县", "永城市",
    "罗山县", "光山县", "新县", "商城县", "固始县", "潢川县", "淮滨县", "息县",
    "扶沟县", "西华县", "商水县", "沈丘县", "郸城县", "太康县", "鹿邑县", "项城市",
    "西平县", "上蔡县", "平舆县", "正阳县", "确山县", "泌阳县", "汝南县",
    "遂平县", "新蔡县",
]
HN_DISTRICTS = [
    "中原区", "二七区", "管城回族区", "金水区", "上街区", "惠济区",
    "龙亭区", "顺河回族区", "鼓楼区", "禹王台区", "祥符区",
    "老城区", "西工区", "瀍河回族区", "涧西区", "偃师区", "孟津区", "洛龙区",
    "新华区", "卫东区", "石龙区", "湛河区",
    "文峰区", "北关区", "殷都区", "龙安区",
    "鹤山区", "山城区", "淇滨区",
    "红旗区", "卫滨区", "凤泉区", "牧野区",
    "解放区", "中站区", "马村区", "山阳区",
    "华龙区", "魏都区", "建安区",
    "源汇区", "郾城区", "召陵区",
    "湖滨区", "陕州区",
    "宛城区", "卧龙区",
    "梁园区", "睢阳区",
    "浉河区", "平桥区",
    "川汇区", "淮阳区", "驿城区",
]


def _build_lookup(names, level):
    """把'中牟县'这类全名映射成查询表，同时登记去掉后缀的核心词。"""
    table = {}
    for full in names:
        core = re.sub(r"(回族|畲族|满族|蒙古族|土家族|苗族|壮族)?(自治县|县|市|区)$", "", full)
        if len(core) >= 2 and core not in HN_CITIES:
            table.setdefault(core, (full, level))
        table.setdefault(full, (full, level))
    return table


HN_LOOKUP = {**_build_lookup(HN_COUNTIES, "县"), **_build_lookup(HN_DISTRICTS, "市辖区")}


def _is_city_token(token: str) -> bool:
    cleaned = token.replace("市", "").replace("周边", "").replace("地区", "").strip()
    return cleaned in HN_CITIES


def parse_henan_region(label):
    """解析河南平台标签，返回 (县级单位标准名, 行政级别)；无法归属返回 (None, None)。"""
    if label is None or (isinstance(label, float) and np.isnan(label)):
        return None, None
    parts = [p.strip() for p in re.split(r"[-—－]", str(label).strip()) if p.strip()]
    if not parts:
        return None, None

    if len(parts) == 1:
        token = parts[0]
        if _is_city_token(token) or token in NON_COUNTY:
            return None, None
        hit = HN_LOOKUP.get(token)
        return hit if hit else (None, None)

    first, second = parts[0], parts[1]
    if first in NON_COUNTY or _is_city_token(first):
        order = [second, first]
    else:
        order = [first, second]
    for token in order:
        if token in NON_COUNTY:
            continue
        hit = HN_LOOKUP.get(token)
        if hit:
            return hit
    return None, None


def parse_henan_city(label):
    """从河南标签里尽量取出地级市名，用于聚类标准误。"""
    if label is None or (isinstance(label, float) and np.isnan(label)):
        return None
    parts = [p.strip() for p in re.split(r"[-—－]", str(label).strip()) if p.strip()]
    for token in parts:
        cleaned = token.replace("市", "").replace("周边", "").replace("地区", "").strip()
        if cleaned in HN_CITIES:
            return cleaned
    return None


# ---------------------------------------------------------------- 读入与清洗
def load_raw(province: str) -> pd.DataFrame:
    df = pd.read_excel(SOURCES[province], sheet_name=0)
    df = df.loc[:, ~df.columns.astype(str).str.startswith("Unnamed")]
    df["省"] = province
    return df


def clean(df: pd.DataFrame) -> pd.DataFrame:
    out = pd.DataFrame()
    out["省"] = df["省"]

    if df["省"].iloc[0] == "河南":
        out["地级市"] = df["工作区域"].map(parse_henan_city)
        parsed = df["工作区域"].map(parse_henan_region)
        out["县区"] = [p[0] for p in parsed]
        out["行政级别"] = [p[1] for p in parsed]
    else:
        city = df["工作城市"].astype(str).str.strip().str.replace("市", "", regex=False)
        out["地级市"] = city
        region = df["工作区域"].astype(str).str.strip()
        out["县区"] = region.where(df["工作区域"].notna())
        out["行政级别"] = out["县区"].map(
            lambda x: "县级市" if isinstance(x, str) and x.endswith("市")
            else ("市辖区" if isinstance(x, str) and x.endswith("区")
                  else ("县" if isinstance(x, str) else None))
        )

    out["原始标签"] = df["工作区域"].astype(str)
    out["学历要求原文"] = df["学历要求"].where(df["学历要求"].notna()).astype(str)
    out["学历门槛"] = df["学历要求"].map(classify_education)
    out["门槛分值"] = out["学历门槛"].map(TIER_SCORE)

    # 0/1 变量（重新生成，替换原表）
    score = out["门槛分值"]
    out["要求大专及以上"] = (score >= 3).astype(int)
    out["要求本科及以上"] = (score >= 4).astype(int)
    out["要求硕士及以上"] = (score >= 5).astype(int)
    out["要求高中及以上"] = (score >= 2).astype(int)
    out["初中及以下"] = (out["学历门槛"] == "初中及以下").astype(int)
    out["学历不限"] = (out["学历门槛"] == "学历不限").astype(int)
    out["学历未注明"] = (out["学历门槛"] == "未注明").astype(int)
    out["明确学历门槛"] = (score.notna() & (out["学历不限"] == 0)).astype(int)

    out["招聘人数"] = df["招聘人数"].map(parse_headcount)
    out["招聘人数缺失"] = out["招聘人数"].isna().astype(int)

    low = pd.to_numeric(df["最低月薪"], errors="coerce")
    high = pd.to_numeric(df["最高月薪"], errors="coerce")
    out["月薪中值"] = (low + high) / 2
    out["月薪缺失"] = out["月薪中值"].isna().astype(int)

    return out


def main():
    frames = []
    rules = []
    for province, path in SOURCES.items():
        raw = load_raw(province)
        frames.append(clean(raw))
        mapping = raw["学历要求"].astype(str).value_counts().rename("频次").reset_index()
        mapping.columns = ["学历要求原文", "频次"]
        mapping["归入门槛"] = mapping["学历要求原文"].map(classify_education)
        mapping["省"] = province
        rules.append(mapping)

    detail = pd.concat(frames, ignore_index=True)

    # 统一口径：把缺失省/市/县补齐为可读标记
    detail["县区"] = detail["县区"].fillna("未归属县区")
    detail["地级市"] = detail["地级市"].fillna("未识别")

    # 编码规则表
    rule_table = pd.concat(rules, ignore_index=True)[
        ["省", "学历要求原文", "频次", "归入门槛"]
    ].sort_values(["省", "频次"], ascending=[True, False])

    # 明细表
    detail_cols = [
        "省", "地级市", "县区", "行政级别", "原始标签", "学历要求原文", "学历门槛", "门槛分值",
        "要求大专及以上", "要求本科及以上", "要求硕士及以上", "要求高中及以上",
        "初中及以下", "学历不限", "学历未注明", "明确学历门槛",
        "招聘人数", "招聘人数缺失", "月薪中值", "月薪缺失",
    ]
    detail = detail[detail_cols]

    # 县级指标（一县一行）
    def agg_county(group: pd.DataFrame) -> pd.Series:
        valid = group[group["明确学历门槛"] == 1]
        headcount = group["招聘人数"]
        weight = headcount.fillna(0)
        weighted_share = (
            float(np.average(group["要求大专及以上"], weights=weight))
            if weight.sum() > 0 else np.nan
        )
        return pd.Series({
            "广告数": len(group),
            "明确门槛广告数": int(group["明确学历门槛"].sum()),
            "明确门槛广告占比": group["明确学历门槛"].mean(),
            "大专及以上占比": group["要求大专及以上"].mean(),
            "本科及以上占比": group["要求本科及以上"].mean(),
            "硕士及以上占比": group["要求硕士及以上"].mean(),
            "高中及以上占比": group["要求高中及以上"].mean(),
            "初中及以下占比": group["初中及以下"].mean(),
            "学历不限占比": group["学历不限"].mean(),
            "学历未注明占比": group["学历未注明"].mean(),
            "平均门槛分值": valid["门槛分值"].mean() if len(valid) else np.nan,
            "招聘人数合计": headcount.sum(min_count=1),
            "招聘人数缺失率": group["招聘人数缺失"].mean(),
            "有招聘人数广告数": int(headcount.notna().sum()),
            "招聘人数加权_大专及以上占比": weighted_share,
            "月薪中值均值": group["月薪中值"].mean(),
            "月薪缺失率": group["月薪缺失"].mean(),
        })

    county = (
        detail.groupby(["省", "县区"], dropna=False)
        .apply(agg_county, include_groups=False)
        .reset_index()
    )
    # 地级市与行政级别按县归并，避免同一个县因标签差异被拆成多行
    def dominant(series):
        mode = series.dropna().astype(str)
        mode = mode[mode != "未识别"]
        return mode.mode().iloc[0] if len(mode) else "未识别"

    city_map = detail.groupby(["省", "县区"])["地级市"].apply(dominant).rename("地级市")
    level_map = detail.groupby(["省", "县区"])["行政级别"].apply(dominant).rename("行政级别")
    county = county.merge(city_map, on=["省", "县区"], how="left")
    county = county.merge(level_map, on=["省", "县区"], how="left")
    cols = list(county.columns)
    cols.insert(1, cols.pop(cols.index("地级市")))
    cols.insert(2, cols.pop(cols.index("行政级别")))
    county = county[cols].sort_values(["省", "广告数"], ascending=[True, False])

    # B 表接入位：核心解释变量与控制变量列先占位，等成员B的表合并进来
    analysis = county.copy()
    for col in ["平均受教育年限", "大专及以上人口占比", "高中及以上人口占比",
                "常住人口", "人均GDP", "二产就业占比", "三产就业占比"]:
        analysis[col] = np.nan

    with pd.ExcelWriter(OUT / "01_学历编码规则与对照表.xlsx", engine="openpyxl") as w:
        rule_table.to_excel(w, sheet_name="编码规则", index=False)

    with pd.ExcelWriter(OUT / "02_招聘明细_清洗版.xlsx", engine="openpyxl") as w:
        detail.to_excel(w, sheet_name="清洗明细", index=False)
        notes = []
        for province in detail["省"].unique():
            part = detail[detail["省"] == province]
            notes.append({
                "省": province,
                "广告数": len(part),
                "未归属县区广告数": int((part["县区"] == "未归属县区").sum()),
                "未归属占比": (part["县区"] == "未归属县区").mean(),
                "学历未注明广告数": int((part["学历门槛"] == "未注明").sum()),
                "招聘人数缺失率": part["招聘人数缺失"].mean(),
                "月薪缺失率": part["月薪缺失"].mean(),
            })
        pd.DataFrame(notes).to_excel(w, sheet_name="清洗说明", index=False)

    with pd.ExcelWriter(OUT / "03_县级招聘侧指标.xlsx", engine="openpyxl") as w:
        county.to_excel(w, sheet_name="县级指标", index=False)
        county.groupby("省").agg(
            县区数=("县区", "nunique"),
            广告数=("广告数", "sum"),
            大专及以上占比_均值=("大专及以上占比", "mean"),
            未注明占比_均值=("学历未注明占比", "mean"),
        ).reset_index().to_excel(w, sheet_name="分省概览", index=False)

    with pd.ExcelWriter(OUT / "04_分析数据集.xlsx", engine="openpyxl") as w:
        analysis.to_excel(w, sheet_name="分析数据", index=False)

    variable_defs = [
        ("省", "省份", "招聘广告所在省", "招聘平台原始字段", "无缺失"),
        ("地级市", "地级市", "县区所属地级市，用于聚类标准误", "由平台标签解析", "河南未识别标签记为未识别"),
        ("县区", "县级单位", "县级行政区划名称，分析的基本单位", "平台工作区域字段＋县级单位白名单",
         "河南有 699 条广告无法归属，已剔除"),
        ("行政级别", "行政级别", "县 / 县级市 / 市辖区", "按标准名称后缀判定", "可剔除市辖区做稳健性"),
        ("广告数", "招聘广告条数", "该县招聘广告的样本量", "计数", "无缺失"),
        ("明确门槛广告数", "明确门槛广告条数", "学历要求既非不限也未注明的广告数", "计数", "无缺失"),
        ("明确门槛广告占比", "有效样本占比", "明确门槛广告数 / 广告数", "计算", "被解释变量测量精度的代理"),
        ("大专及以上占比", "被解释变量（基准）", "要求大专及以上学历的广告占比", "按学历要求原文重判", "无缺失"),
        ("本科及以上占比", "被解释变量（替代口径）", "要求本科及以上学历的广告占比", "按学历要求原文重判", "无缺失"),
        ("硕士及以上占比", "被解释变量（替代口径）", "要求硕士及以上学历的广告占比", "按学历要求原文重判", "无缺失"),
        ("高中及以上占比", "被解释变量（替代口径）", "要求高中及以上学历的广告占比", "按学历要求原文重判", "无缺失"),
        ("平均门槛分值", "连续型被解释变量", "仅对明确门槛广告计算：不限=0，初中及以下=1，高中及以上=2，大专及以上=3，本科及以上=4，硕士及以上=5",
         "计算", "该县无明确门槛广告时为缺失"),
        ("招聘人数加权_大专及以上占比", "人数加权被解释变量", "以招聘人数为权重的大专及以上占比",
         "计算", "招聘人数全部缺失时为缺失；缺失不按 1 人补"),
        ("招聘人数合计", "招聘人数合计", "该县招聘人数的合计值", "从文本解析为数值", "缺失记 0 不参与合计"),
        ("招聘人数缺失率", "招聘人数缺失率", "招聘人数缺失的广告占比", "计算", "无缺失"),
        ("月薪中值均值", "薪资水平", "（最低月薪＋最高月薪）/2 的县级均值", "计算", "缺失部分不参与均值"),
        ("月薪缺失率", "薪资缺失率", "月薪缺失的广告占比", "计算", "无缺失"),
        ("学历未注明占比", "安慰剂被解释变量", "学历要求无法识别的广告占比", "计算",
         "用于安慰剂检验：若核心解释变量对其同样显著，提示机械相关"),
        ("学历不限占比", "对照被解释变量", "学历要求为不限的广告占比", "计算", "无缺失"),
        ("平均受教育年限", "核心解释变量", "县级平均受教育年限（年）", "待接入（成员B交付）", "当前为空"),
        ("常住人口 / 人均GDP / 二产就业占比 / 三产就业占比", "控制变量",
         "县域人口规模、经济发展水平与产业结构", "待接入（成员B交付）", "当前为空"),
    ]
    with pd.ExcelWriter(OUT / "05_变量定义与数据说明.xlsx", engine="openpyxl") as w:
        pd.DataFrame(variable_defs,
                     columns=["变量名", "中文名", "定义", "来源", "缺失处理"]
                     ).to_excel(w, sheet_name="变量定义", index=False)
        source_note = pd.DataFrame({
            "省": list(SOURCES.keys()),
            "原始文件": [str(p) for p in SOURCES.values()],
            "广告条数": [int((detail["省"] == p).sum()) for p in SOURCES],
            "归入县级单位数": [int(county[county["省"] == p]["县区"].nunique()) for p in SOURCES],
            "未归属县区条数": [int(((detail["省"] == p) & (detail["县区"] == "未归属县区")).sum())
                          for p in SOURCES],
            "学历编码依据": ["学历要求原文重判"] * len(SOURCES),
        })
        source_note.to_excel(w, sheet_name="数据来源与覆盖", index=False)

    print("=== 明细 ===")
    print(detail.groupby("省").agg(
        广告数=("学历门槛", "size"),
        未归属县区=("县区", lambda s: (s == "未归属县区").sum()),
    ).to_string())
    print()
    print("=== 学历门槛分布 ===")
    print(pd.crosstab(detail["省"], detail["学历门槛"]).to_string())
    print()
    print("=== 县级单位数 ===")
    print(county.groupby("省")["县区"].nunique().to_string())
    print()
    print("已输出到", OUT)


if __name__ == "__main__":
    main()
