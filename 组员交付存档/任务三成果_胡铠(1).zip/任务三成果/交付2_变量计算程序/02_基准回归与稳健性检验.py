# -*- coding: utf-8 -*-
"""
任务三 · 第二步：基准回归与稳健性检验

运行方式
    python 02_econometrics.py             正式运行（读 04_分析数据集.xlsx）
    python 02_econometrics.py --selfcheck 程序自检（合成数据，结果不可用于论文）

变量接入（自动按关键词匹配 04_分析数据集.xlsx 的列名，命中即用）
    被解释变量：大专及以上占比 / 本科及以上占比 / …
    核心解释变量：平均受教育年限、大专及以上人口占比、高中及以上人口占比 …
    控制变量：常住人口、人均GDP、二产就业占比、三产就业占比 …
核心解释变量缺失时程序不编造数据，只打印缺失清单并退出。
"""

import argparse
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf
from scipy import stats
from statsmodels.othermod.betareg import BetaModel
from statsmodels.regression.quantile_regression import QuantReg
from statsmodels.sandbox.regression.gmm import IV2SLS
from statsmodels.stats.outliers_influence import OLSInfluence

warnings.filterwarnings("ignore")

ROOT = Path(r"D:\大创不自信版")
T3 = ROOT / "任务三成果"
OUT = T3 / "附件"
EPS = 1e-6

# ------------------------------------------------------------------ 变量注册表
ROLE_PATTERNS = {
    "人力资本_年限": ["平均受教育年限", "受教育年限"],
    "人力资本_大专": ["大专及以上人口占比", "大专以上人口占比"],
    "人力资本_高中": ["高中及以上人口占比", "高中以上人口占比"],
    "人口": ["常住人口", "户籍人口", "人口规模"],
    "经济": ["人均GDP", "人均国内生产总值", "人均地区生产总值"],
    "二产": ["二产就业占比", "第二产业就业占比", "二产占比"],
    "三产": ["三产就业占比", "第三产业就业占比", "三产占比"],
    "城镇化": ["城镇化率", "城镇人口占比"],
}

CONTROL_ORDER = ["人口", "经济", "二产", "三产", "城镇化"]


def match_columns(df, patterns):
    """按关键词在列名中做包含匹配，返回实际存在的列名。"""
    hits = []
    for col in df.columns:
        name = str(col)
        if any(p in name for p in patterns):
            hits.append(col)
    return hits


def resolve_roles(df):
    """把注册表里的角色解析为实际列名。"""
    resolved = {}
    for role, patterns in ROLE_PATTERNS.items():
        hits = match_columns(df, patterns)
        if hits:
            resolved[role] = hits[0]
    return resolved


# ------------------------------------------------------------------ 回归内核
def build_design(df, y, x, controls, fe=None, cluster=None, weights=None):
    """组装回归用的因变量、设计矩阵与分组信息。"""
    used = list(dict.fromkeys([x] + list(controls)
                              + ([fe] if fe else []) + ([cluster] if cluster else [])
                              + ([weights] if weights else [])))
    data = df[[y] + used].dropna().copy()
    if len(data) < 12:
        return None

    yv = data[y].astype(float).values
    X = data[[x] + list(controls)].astype(float)
    if fe:
        dummies = pd.get_dummies(data[fe].astype(str), prefix=fe, drop_first=True)
        X = pd.concat([X, dummies.astype(float)], axis=1)
    X = sm.add_constant(X, has_constant="add")
    groups = data[cluster].astype(str).values if cluster else None
    w = data[weights].astype(float).values if weights else None
    return {"y": yv, "X": X, "groups": groups, "w": w, "n": len(data)}


def fit_ols(df, y, x, controls=(), fe=None, cluster=None, weights=None,
            cov="HC1", transform=None):
    """OLS / 加权最小二乘 / 聚类稳健标准误。transform 可对 y 做变换。"""
    work = df
    if transform is not None:
        work = df.copy()
        work[y] = transform(work[y])
    design = build_design(work, y, x, controls, fe, cluster, weights)
    if design is None:
        return None
    model = sm.WLS(design["y"], design["X"], weights=design["w"]) if weights else \
        sm.OLS(design["y"], design["X"])
    if cluster and design["groups"] is not None:
        res = model.fit(cov_type="cluster", cov_kwds={"groups": design["groups"]})
    else:
        res = model.fit(cov_type=cov)
    if x not in res.params.index:
        return None
    return {
        "coef": float(res.params[x]),
        "se": float(res.bse[x]),
        "p": float(res.pvalues[x]),
        "n": int(res.nobs),
        "r2": float(res.rsquared),
        "ci_low": float(res.conf_int().loc[x, 0]),
        "ci_high": float(res.conf_int().loc[x, 1]),
        "fitted": res,
        "design": design,
    }


def fit_fractional_logit(df, y, x, controls=(), fe=None):
    """比例型被解释变量：二项族 GLM（稳健方差）——分数 logit。"""
    design = build_design(df, y, x, controls, fe)
    if design is None:
        return None
    yv = np.clip(design["y"], EPS, 1 - EPS)
    res = sm.GLM(yv, design["X"], family=sm.families.Binomial()).fit(cov_type="HC1")
    if x not in res.params.index:
        return None
    return {"coef": float(res.params[x]), "se": float(res.bse[x]), "p": float(res.pvalues[x]),
            "n": int(res.nobs), "r2": np.nan}


def fit_beta(df, y, x, controls=(), fe=None):
    """Beta 回归：适用于 (0,1) 区间的比例被解释变量。"""
    design = build_design(df, y, x, controls, fe)
    if design is None:
        return None
    yv = np.clip(design["y"], EPS, 1 - EPS)
    try:
        res = BetaModel(yv, design["X"]).fit(disp=0)
    except Exception:
        return None
    if x not in res.params.index:
        return None
    return {"coef": float(res.params[x]), "se": float(res.bse[x]), "p": float(res.pvalues[x]),
            "n": int(res.nobs), "r2": np.nan}


def fit_quantile(df, y, x, controls=(), q=0.5):
    """中位数回归（对被解释变量分布右尾不敏感）。"""
    design = build_design(df, y, x, controls)
    if design is None:
        return None
    res = QuantReg(design["y"], design["X"]).fit(q=q)
    if x not in res.params.index:
        return None
    return {"coef": float(res.params[x]), "se": float(res.bse[x]), "p": float(res.pvalues[x]),
            "n": int(res.nobs), "r2": np.nan}


def fit_iv(df, y, x, instrument, controls=()):
    """两阶段最小二乘：以 instrument 作为核心解释变量的工具变量。"""
    if instrument is None or instrument not in df.columns:
        return None
    used = list(dict.fromkeys([y, x, instrument] + list(controls)))
    data = df[used].dropna()
    if len(data) < 15:
        return None
    exog = sm.add_constant(data[[x] + list(controls)].astype(float), has_constant="add")
    endog = data[[instrument]].astype(float)      # 工具变量作为待预测的核心解释变量
    try:
        res = IV2SLS(data[y].astype(float), exog, endog).fit()
    except Exception:
        return None
    if instrument not in res.params.index:
        return None
    return {"coef": float(res.params[instrument]), "se": float(res.bse[instrument]),
            "p": float(res.pvalues[instrument]), "n": int(res.nobs), "r2": np.nan}


# ------------------------------------------------------------------ 敏感性工具
def oster_delta(df, y, x, controls=()):
    """Oster(2019) 遗漏变量偏误检验：报告 delta 与偏误校正后的系数。"""
    base = fit_ols(df, y, x, controls=())
    full = fit_ols(df, y, x, controls=controls)
    if base is None or full is None:
        return None
    r_max = min(1.0, 1.3 * full["r2"])
    gain = full["r2"] - base["r2"]      # 加入控制变量带来的 R² 增量
    if (r_max - full["r2"]) <= 0 or gain <= 0:
        return None
    beta_star = full["coef"] - (base["coef"] - full["coef"]) * (r_max - full["r2"]) / gain
    # delta 表示"不可观测变量的选择强度需达到可观测变量的多少倍，才能把系数压到 0"
    delta = (full["coef"] * gain) / ((base["coef"] - full["coef"]) * (r_max - full["r2"]))
    return {"beta_无控制": base["coef"], "beta_全控制": full["coef"],
            "R2_无控制": base["r2"], "R2_全控制": full["r2"],
            "Rmax": r_max, "beta_star": beta_star, "delta": delta}


def altonji_ratio(df, y, x, controls=()):
    """Altonji 等比值：可观测变量的选择效应相对不可观测变量的倍数。"""
    base = fit_ols(df, y, x, controls=())
    full = fit_ols(df, y, x, controls=controls)
    if base is None or full is None:
        return None
    gap = base["coef"] - full["coef"]
    return {"比值": np.inf if abs(gap) < 1e-12 else full["coef"] / gap,
            "beta_无控制": base["coef"], "beta_全控制": full["coef"]}


def permutation_test(df, y, x, controls=(), n_boot=500, seed=20260926):
    """置换检验：随机打乱核心解释变量，得到系数的零分布与经验 p 值。"""
    base = fit_ols(df, y, x, controls=controls)
    if base is None:
        return None
    rng = np.random.default_rng(seed)
    draws = []
    for _ in range(n_boot):
        shuffled = df.copy()
        shuffled[x] = rng.permutation(shuffled[x].values)
        hit = fit_ols(shuffled, y, x, controls=controls)
        if hit:
            draws.append(hit["coef"])
    if not draws:
        return None
    draws = np.array(draws)
    p_emp = float((np.abs(draws) >= abs(base["coef"])).mean())
    return {"系数": base["coef"], "置换均值": float(draws.mean()),
            "置换标准差": float(draws.std(ddof=1)), "经验p值": p_emp,
            "迭代次数": len(draws)}


def bootstrap_se(df, y, x, controls=(), n_boot=500, seed=20260926):
    """成对自助法标准误（县为单位重抽）。"""
    if len(df) < 15:
        return None
    rng = np.random.default_rng(seed)
    draws = []
    for _ in range(n_boot):
        idx = rng.integers(0, len(df), len(df))
        hit = fit_ols(df.iloc[idx], y, x, controls=controls)
        if hit:
            draws.append(hit["coef"])
    if len(draws) < 50:
        return None
    return {"系数": float(np.mean(draws)), "自助标准误": float(np.std(draws, ddof=1)),
            "迭代次数": len(draws)}


def moran_like_icc(res):
    """残差的空间/组内相关检验（地级市内 ICC，用于判断是否需聚类）。"""
    if res is None or "fitted" not in res:
        return None
    resid = res["fitted"].resid.values
    if "groups" not in res["design"] or res["design"]["groups"] is None:
        return None
    groups = pd.Series(res["design"]["groups"])
    overall_var = float(np.var(resid, ddof=1))
    if overall_var <= 0:
        return None
    sizes = groups.value_counts()
    keep = groups.isin(sizes[sizes > 1].index)
    if keep.sum() < 10:
        return None
    frame = pd.DataFrame({"g": groups[keep].values, "e": resid[keep.values]})
    means = frame.groupby("g")["e"].mean()
    between = float(means.var(ddof=1))
    within = float(frame.groupby("g")["e"].var(ddof=1).mean())
    icc = between / (between + within) if (between + within) > 0 else np.nan
    return {"组间方差": between, "组内方差": within, "组内相关系数ICC": icc,
            "组数": int(means.size)}


# ------------------------------------------------------------------ 输出格式
COLS = ["检验类别", "检验名称", "被解释变量", "核心解释变量", "样本", "估计方法",
        "系数", "标准误", "p值", "样本量", "R2", "说明"]


def record(category, name, res, dv, key, sample, method, note=""):
    if res is None:
        return None
    row = dict.fromkeys(COLS)
    row.update({
        "检验类别": category, "检验名称": name, "被解释变量": dv, "核心解释变量": key,
        "样本": sample, "估计方法": method,
        "系数": round(res["coef"], 4), "标准误": round(res["se"], 4),
        "p值": round(res["p"], 4), "样本量": res["n"],
        "R2": None if res.get("r2") is None or np.isnan(res.get("r2", np.nan))
              else round(res["r2"], 4),
        "说明": note,
    })
    return row


def stars(p):
    if p is None or not np.isfinite(p):
        return ""
    return "***" if p < 0.01 else ("**" if p < 0.05 else ("*" if p < 0.1 else ""))


def winsorize(series, lower=0.01, upper=0.99):
    lo, hi = series.quantile(lower), series.quantile(upper)
    return series.clip(lo, hi)


def usable_counties(df):
    """剔除没有归属到县级单位的样本。"""
    out = df.copy()
    if "县区" in out.columns:
        out = out[out["县区"].notna()]
        out = out[out["县区"].astype(str) != "未归属县区"]
    return out


# ------------------------------------------------------------------ 稳健性检验主流程
DV_CANDIDATES = [
    "大专及以上占比", "本科及以上占比", "硕士及以上占比", "高中及以上占比",
    "初中及以下占比", "平均门槛分值", "招聘人数加权_大专及以上占比",
    "学历不限占比", "学历未注明占比",
]

INSTRUMENT_KEYWORDS = ["学校数", "学校", "距离", "地形", "坡度", "海拔", "历史", "旧"]


def run_battery(df, key, controls, dv="大专及以上占比", label="正式",
                cluster_city="地级市", cluster_prov="省"):
    """跑完整的基准回归 + 稳健性检验，返回结果行与跳过记录。"""
    rows, skipped = [], []

    def add(category, name, res, dv_used, sample, method, note="", frame=None):
        row = record(category, name, res, dv_used, key, sample, method, note)
        if row is None:
            skipped.append({"检验类别": category, "检验名称": name,
                            "原因": "样本量不足或模型不可估计"})
        else:
            rows.append(row)
        return res

    base_controls = [c for c in controls if c in df.columns]

    # ---------- 0 基准回归
    add("0 基准", "基准回归", fit_ols(df, dv, key, base_controls, cov="HC1"),
        dv, "全样本", "OLS·异方差稳健")
    add("0 基准", "无控制变量", fit_ols(df, dv, key), dv, "全样本", "OLS·HC1")

    # ---------- 1 被解释变量口径
    for y in DV_CANDIDATES:
        if y not in df.columns or y == dv:
            continue
        note = "安慰剂：理论上不应显著" if "未注明" in y else ""
        add("1 被解释变量口径", f"以「{y}」为被解释变量",
            fit_ols(df, y, key, base_controls, cov="HC1"), y, "全样本", "OLS·HC1", note)

    # ---------- 2 样本范围
    samples = {
        "广告数≥30": df[df["广告数"] >= 30],
        "广告数≥50": df[df["广告数"] >= 50],
        "广告数≥100": df[df["广告数"] >= 100],
    }
    if "明确门槛广告数" in df.columns:
        samples["明确门槛广告数≥30"] = df[df["明确门槛广告数"] >= 30]
    if "学历未注明占比" in df.columns:
        samples["剔除未注明占比>20%"] = df[df["学历未注明占比"] <= 0.20]
        samples["剔除未注明占比>30%"] = df[df["学历未注明占比"] <= 0.30]
    if "明确门槛广告占比" in df.columns:
        samples["剔除明确门槛占比<50%"] = df[df["明确门槛广告占比"] >= 0.50]
    if "行政级别" in df.columns:
        samples["仅保留县与县级市"] = df[df["行政级别"] != "市辖区"]
    if "月薪缺失率" in df.columns:
        samples["剔除月薪缺失率>50%"] = df[df["月薪缺失率"] <= 0.50]

    tmp = df.copy()
    tmp["_y_w1"] = winsorize(tmp[dv], 0.01, 0.99)
    tmp["_y_w5"] = winsorize(tmp[dv], 0.05, 0.95)
    tmp["_key_w1"] = winsorize(tmp[key].astype(float), 0.01, 0.99)
    samples["被解释变量缩尾1%"] = tmp
    samples["被解释变量缩尾5%"] = tmp
    samples["核心解释变量缩尾1%"] = tmp

    for name, sub in samples.items():
        if len(sub) < 15:
            skipped.append({"检验类别": "2 样本范围", "检验名称": name,
                            "原因": f"样本量仅 {len(sub)}，不足 15"})
            continue
        if "缩尾" in name:
            y_col = "_y_w1" if "1%" in name and "被解释变量" in name else \
                ("_y_w5" if "被解释变量" in name else dv)
            x_col = "_key_w1" if "核心解释变量" in name else key
            add("2 样本范围", name, fit_ols(sub, y_col, x_col, base_controls, cov="HC1"),
                y_col, name, "OLS·HC1", "缩尾后重估")
        else:
            add("2 样本范围", name, fit_ols(sub, dv, key, base_controls, cov="HC1"),
                dv, name, "OLS·HC1")

    # 影响点：按 Cook 距离剔除
    base_fit = fit_ols(df, dv, key, base_controls, cov="HC1")
    if base_fit is not None:
        try:
            influence = OLSInfluence(base_fit["fitted"])
            cooks = pd.Series(influence.cooks_distance[0], index=base_fit["design"]["X"].index)
            for cut, tag in [(0.99, "1%"), (0.95, "5%")]:
                keep_idx = cooks[cooks <= cooks.quantile(cut)].index
                sub = df.loc[df.index.intersection(keep_idx)]
                add("2 样本范围", f"剔除Cook距离前{tag}影响点",
                    fit_ols(sub, dv, key, base_controls, cov="HC1"), dv, f"剔除前{tag}", "OLS·HC1")
        except Exception as exc:
            skipped.append({"检验类别": "2 样本范围", "检验名称": "Cook 距离检验",
                            "原因": f"计算失败：{exc}"})

    # ---------- 3 核心解释变量口径
    std_key = df.copy()
    std_key["_key_z"] = (std_key[key] - std_key[key].mean()) / std_key[key].std(ddof=1)
    add("3 核心解释变量口径", "核心解释变量标准化",
        fit_ols(std_key, dv, "_key_z", base_controls, cov="HC1"), dv, "全样本", "OLS·HC1",
        "系数解释为每提高 1 个标准差")
    logit_key = df.copy()
    logit_key["_key_logit"] = np.log(
        np.clip(logit_key[key].astype(float), EPS, 1 - EPS) /
        (1 - np.clip(logit_key[key].astype(float), EPS, 1 - EPS))
    ) if df[key].between(0, 1).all() else None
    if logit_key["_key_logit"] is not None:
        add("3 核心解释变量口径", "核心解释变量 logit 变换",
            fit_ols(logit_key, dv, "_key_logit", base_controls, cov="HC1"), dv, "全样本", "OLS·HC1")
    med = df[key].median()
    grp = df.copy()
    grp["_key_high"] = (grp[key] > med).astype(int)
    add("3 核心解释变量口径", "核心解释变量是否高于中位数",
        fit_ols(grp, dv, "_key_high", base_controls, cov="HC1"), dv, "全样本", "OLS·HC1",
        "改为虚拟变量，降低函数形式依赖")
    quart = df.copy()
    quart["_key_q"] = pd.qcut(quart[key], 4, labels=False, duplicates="drop")
    add("3 核心解释变量口径", "核心解释变量四分位序数",
        fit_ols(quart, dv, "_key_q", base_controls, cov="HC1"), dv, "全样本", "OLS·HC1",
        "检验是否存在非线性")
    for role, col in resolve_roles(df).items():
        if col == key or not role.startswith("人力资本"):
            continue
        add("3 核心解释变量口径", f"替换为核心解释变量「{col}」",
            fit_ols(df, dv, col, base_controls, cov="HC1"), dv, "全样本", "OLS·HC1")

    # ---------- 4 控制变量与控制集
    for i in range(len(base_controls) + 1):
        subset = base_controls[:i]
        name = "无控制变量" if i == 0 else "加入" + "、".join(subset)
        add("4 控制变量", name, fit_ols(df, dv, key, subset, cov="HC1"),
            dv, "全样本", "OLS·HC1")
    if cluster_city in df.columns:
        add("4 控制变量", "地级市固定效应",
            fit_ols(df, dv, key, base_controls, fe=cluster_city, cov="HC1"),
            dv, "全样本", "OLS·HC1", "吸收地级市层面不可观测因素")
    if cluster_prov in df.columns:
        add("4 控制变量", "省份固定效应",
            fit_ols(df, dv, key, base_controls, fe=cluster_prov, cov="HC1"),
            dv, "全样本", "OLS·HC1")
    if "广告数" in df.columns:
        ctrl2 = df.copy()
        ctrl2["_ln_ads"] = np.log(ctrl2["广告数"].clip(lower=1))
        add("4 控制变量", "控制样本规模 log(广告数)",
            fit_ols(ctrl2, dv, key, base_controls + ["_ln_ads"], cov="HC1"),
            dv, "全样本", "OLS·HC1")

    # ---------- 5 估计方法
    add("5 估计方法", "分数 logit", fit_fractional_logit(df, dv, key, base_controls),
        dv, "全样本", "GLM·二项族")
    add("5 估计方法", "Beta 回归", fit_beta(df, dv, key, base_controls),
        dv, "全样本", "Beta")
    add("5 估计方法", "中位数回归", fit_quantile(df, dv, key, base_controls, q=0.5),
        dv, "全样本", "QuantReg·q=0.5")
    add("5 估计方法", "75 分位回归", fit_quantile(df, dv, key, base_controls, q=0.75),
        dv, "全样本", "QuantReg·q=0.75")
    if "广告数" in df.columns:
        add("5 估计方法", "按广告数加权最小二乘",
            fit_ols(df, dv, key, base_controls, weights="广告数", cov="HC1"),
            dv, "全样本", "WLS·权重=广告数", "让样本量大的县占更大权重")
    if "招聘人数合计" in df.columns:
        add("5 估计方法", "按招聘人数加权最小二乘",
            fit_ols(df, dv, key, base_controls, weights="招聘人数合计", cov="HC1"),
            dv, "全样本", "WLS·权重=招聘人数")
    instrument = None
    for col in df.columns:
        if any(k in str(col) for k in INSTRUMENT_KEYWORDS):
            instrument = col
            break
    if instrument:
        add("5 估计方法", f"工具变量 2SLS（工具：{instrument}）",
            fit_iv(df, dv, key, instrument, base_controls), dv, "全样本", "IV2SLS",
            "需额外论证工具变量的排他性")
    else:
        skipped.append({"检验类别": "5 估计方法", "检验名称": "工具变量 2SLS",
                        "原因": "数据集中没有可用作工具变量的列"})

    # ---------- 6 推断方式
    for cov in ["HC1", "HC3", "nonrobust"]:
        add("6 推断方式", f"标准误类型 {cov}",
            fit_ols(df, dv, key, base_controls, cov=cov), dv, "全样本", f"OLS·{cov}")
    if cluster_city in df.columns:
        add("6 推断方式", f"聚类到{cluster_city}", 
            fit_ols(df, dv, key, base_controls, cluster=cluster_city),
            dv, "全样本", "OLS·聚类稳健", "允许同地市内扰动项相关")
    if cluster_prov in df.columns:
        add("6 推断方式", f"聚类到{cluster_prov}",
            fit_ols(df, dv, key, base_controls, cluster=cluster_prov),
            dv, "全样本", "OLS·聚类稳健")
    boot = bootstrap_se(df, dv, key, base_controls)
    if boot:
        rows.append({"检验类别": "6 推断方式", "检验名称": "成对自助法标准误",
                     "被解释变量": dv, "核心解释变量": key, "样本": "全样本",
                     "估计方法": f"Bootstrap({boot['迭代次数']}次)",
                     "系数": round(boot["系数"], 4), "标准误": round(boot["自助标准误"], 4),
                     "p值": None, "样本量": len(df), "R2": None,
                     "说明": "按县重抽"})
    perm = permutation_test(df, dv, key, base_controls)
    if perm:
        rows.append({"检验类别": "6 推断方式", "检验名称": "置换检验",
                     "被解释变量": dv, "核心解释变量": key, "样本": "全样本",
                     "估计方法": f"Permutation({perm['迭代次数']}次)",
                     "系数": round(perm["系数"], 4),
                     "标准误": round(perm["置换标准差"], 4),
                     "p值": round(perm["经验p值"], 4), "样本量": len(df), "R2": None,
                     "说明": "经验 p 值，不依赖正态假设"})
    icc = moran_like_icc(fit_ols(df, dv, key, base_controls, cluster=cluster_city,
                                 cov="HC1") if cluster_city in df.columns else None)
    if icc:
        rows.append({"检验类别": "6 推断方式", "检验名称": "残差组内相关（ICC）",
                     "被解释变量": dv, "核心解释变量": key, "样本": "全样本",
                     "估计方法": "方差分解", "系数": None, "标准误": None, "p值": None,
                     "样本量": icc["组数"], "R2": None,
                     "说明": f"ICC={icc['组内相关系数ICC']:.3f}，越大越说明需要按"
                             f"{cluster_city}聚类"})

    # ---------- 7 敏感性
    oster = oster_delta(df, dv, key, base_controls)
    if oster:
        rows.append({"检验类别": "7 敏感性", "检验名称": "Oster 遗漏变量偏误",
                     "被解释变量": dv, "核心解释变量": key, "样本": "全样本",
                     "估计方法": "Oster(2019)", "系数": round(oster["beta_star"], 4),
                     "标准误": None, "p值": None, "样本量": len(df), "R2": None,
                     "说明": f"delta={oster['delta']:.2f}，Rmax={oster['Rmax']:.3f}，"
                             f"校正后系数={oster['beta_star']:.4f}"})
    alt = altonji_ratio(df, dv, key, base_controls)
    if alt:
        rows.append({"检验类别": "7 敏感性", "检验名称": "Altonji 比值",
                     "被解释变量": dv, "核心解释变量": key, "样本": "全样本",
                     "估计方法": "比值检验", "系数": round(alt["比值"], 3),
                     "标准误": None, "p值": None, "样本量": len(df), "R2": None,
                     "说明": "比值越大，结果对不可观测变量越稳健（>1 通常视为较稳）"})

    # ---------- 8 分样本
    if cluster_prov in df.columns:
        for province in sorted(df[cluster_prov].dropna().unique()):
            sub = df[df[cluster_prov] == province]
            if len(sub) < 15:
                skipped.append({"检验类别": "8 分样本", "检验名称": f"仅{province}",
                                "原因": f"样本量仅 {len(sub)}"})
                continue
            add("8 分样本", f"仅{province}",
                fit_ols(sub, dv, key, base_controls, cov="HC1"), dv, f"仅{province}", "OLS·HC1")
        east = df[df[cluster_prov].isin(["浙江", "四川"])]
        if len(east) >= 15:
            add("8 分样本", "浙江+四川（剔除河南）",
                fit_ols(east, dv, key, base_controls, cov="HC1"), dv, "浙+川", "OLS·HC1",
                "河南招聘数据缺失严重，检验结论是否由河南样本驱动")

    # ---------- 9 学历供需结构差异指数（需同县同期求职者学历数据）
    supply_cols = [c for c in df.columns if any(k in str(c) for k in ("求职者", "供给"))]
    if supply_cols:
        idx = df.copy()
        demand = idx[dv].astype(float)
        supply = idx[supply_cols[0]].astype(float)
        idx["供需差异指数"] = (demand - supply).abs()
        for name, y_col in [("供需差异指数", "供需差异指数"),
                            ("供给缺口（需求-供给）", "供给缺口")]:
            if y_col == "供给缺口":
                idx["供给缺口"] = demand - supply
            add("9 供需匹配", f"以「{name}」为被解释变量",
                fit_ols(idx, y_col, key, base_controls, cov="HC1"), y_col, "全样本", "OLS·HC1",
                "任务书要求的错配回归：需同县同期求职者学历数据")
    else:
        skipped.append({"检验类别": "9 供需匹配", "检验名称": "学历供需结构差异指数",
                        "原因": "数据集中没有按县、按学历划分的求职者数据"})

    return pd.DataFrame(rows), pd.DataFrame(skipped)


# ------------------------------------------------------------------ 稳健性检验清单
CHECKLIST = [
    ("1 被解释变量口径", "更换学历门槛", "大专及以上占比 → 本科及以上 / 硕士及以上",
     "结论是否只在某一个门槛上成立", "已实现"),
    ("1 被解释变量口径", "引入更低门槛", "以「高中及以上占比」重估",
     "需求端学历结构的整体形态", "已实现"),
    ("1 被解释变量口径", "连续型被解释变量", "以各县「平均学历门槛分值」重估",
     "避免单一门槛的截断信息损失", "已实现"),
    ("1 被解释变量口径", "招聘人数加权", "用人数加权的招聘广告占比",
     "防止大企业广告条数主导结果", "已实现"),
    ("1 被解释变量口径", "分数 logit", "比例型因变量的 GLM 估计",
     "线性概率模型的函数形式偏误", "已实现"),
    ("1 被解释变量口径", "Beta 回归", "(0,1) 区间的专门分布假定",
     "比例数据的方差随均值变化", "已实现"),
    ("1 被解释变量口径", "安慰剂检验", "以「学历未注明占比」为被解释变量",
     "若同样显著则提示机械相关或缺失系统性", "已实现"),
    ("2 样本范围", "最小样本量阈值", "广告数 ≥30 / ≥50 / ≥100 分别重估",
     "结论是否由小样本县驱动", "已实现"),
    ("2 样本范围", "有效门槛样本", "明确门槛广告数 ≥30 的县",
     "剔除「不限/未注明」占比过高的县", "已实现"),
    ("2 样本范围", "缺失比例过滤", "剔除未注明占比 >20% / >30% 的县",
     "缺失信息的系统性差异", "已实现"),
    ("2 样本范围", "有效样本占比过滤", "剔除明确门槛占比 <50% 的县",
     "被解释变量测量精度", "已实现"),
    ("2 样本范围", "行政级别过滤", "仅保留县与县级市，剔除市辖区",
     "市辖区与县域的经济结构差异", "已实现"),
    ("2 样本范围", "薪资缺失过滤", "剔除月薪缺失率 >50% 的县",
     "招聘信息完整度差异", "已实现"),
    ("2 样本范围", "缩尾处理", "被解释变量 / 核心解释变量 1% 与 5% 缩尾",
     "极端值影响", "已实现"),
    ("2 样本范围", "影响点诊断", "按 Cook 距离剔除前 1% / 5% 样本",
     "个别强影响点是否改变结论", "已实现"),
    ("2 样本范围", "样本量加权", "以广告数为权重做加权最小二乘",
     "小样本县的噪声", "已实现"),
    ("3 核心解释变量口径", "标准化", "核心解释变量转成 z 分数",
     "系数的经济含义是否稳定", "已实现"),
    ("3 核心解释变量口径", "非线性变换", "对核心解释变量做 logit 变换",
     "函数形式敏感性", "已实现"),
    ("3 核心解释变量口径", "虚拟变量化", "是否高于中位数的 0/1 变量",
     "降低函数形式依赖", "已实现"),
    ("3 核心解释变量口径", "四分位序数", "用分位序数替代连续值",
     "是否存在非线性梯度", "已实现"),
    ("3 核心解释变量口径", "替换人力资本度量", "平均受教育年限 ↔ 大专及以上人口占比 ↔ 高中及以上人口占比",
     "结论对人力资本度量方式是否敏感", "需 B 表提供多个度量"),
    ("3 核心解释变量口径", "改用普查年份", "2010 年与 2020 年两套人力资本数据分别回归",
     "人力资本测度年份差异", "需 B 表提供多年数据"),
    ("4 控制变量与固定效应", "控制变量逐步加入", "从无控制到全控制逐个加入",
     "系数对控制集的敏感性（Oster 检验的基础）", "已实现"),
    ("4 控制变量与固定效应", "地级市固定效应", "吸收地级市层面共同冲击",
     "地区层面的遗漏变量", "已实现"),
    ("4 控制变量与固定效应", "省份固定效应", "吸收省际差异",
     "省际制度与统计口径差异", "已实现"),
    ("4 控制变量与固定效应", "样本规模控制", "加入 log(广告数)",
     "样本量与产业结构相关", "已实现"),
    ("4 控制变量与固定效应", "职业结构控制", "控制职位大类构成",
     "岗位结构是遗漏变量的主要来源", "需原始数据的职业编码"),
    ("4 控制变量与固定效应", "企业规模控制", "控制企业注册资本或规模标签",
     "招聘方特征差异", "需原始数据"),
    ("4 控制变量与固定效应", "平台来源控制", "控制招聘平台固定效应",
     "不同平台的学历标注习惯不同", "需原始数据标注来源平台"),
    ("5 函数形式与估计方法", "中位数与分位回归", "q=0.5 与 q=0.75",
     "分布位置不同的县是否一致", "已实现"),
    ("5 函数形式与估计方法", "工具变量 2SLS", "以历史教育设施或地理距离为工具",
     "反向因果与测量误差", "需 B 表或原始数据提供工具变量"),
    ("5 函数形式与估计方法", "断点/门槛模型", "以人力资本中位数分组回归",
     "非线性效应", "已实现(分组形式)"),
    ("6 统计推断", "标准误类型", "HC1 / HC3 / 经典标准误",
     "异方差处理方式", "已实现"),
    ("6 统计推断", "聚类标准误", "聚类到地级市 / 到省份",
     "组内扰动项相关", "已实现"),
    ("6 统计推断", "自助法", "按县成对重抽 500 次",
     "小样本下的分布假定", "已实现"),
    ("6 统计推断", "置换检验", "随机打乱核心解释变量 500 次",
     "不依赖参数假设的经验 p 值", "已实现"),
    ("6 统计推断", "残差组内相关", "计算地级市内残差 ICC",
     "判断聚类层级是否充分", "已实现"),
    ("6 统计推断", "多重检验校正", "对全部稳健性分支做 Bonferroni 与 Holm 校正",
     "大量检验带来的假阳性", "已实现"),
    ("7 遗漏变量与敏感性", "Oster 检验", "报告 delta 与偏误校正后的系数",
     "不可观测变量的影响需要多强才能推翻结论", "已实现"),
    ("7 遗漏变量与敏感性", "Altonji 比值", "不可观测变量相对可观测变量的选择强度",
     "遗漏变量偏误的相对大小", "已实现"),
    ("7 遗漏变量与敏感性", "系数稳定性统计", "统计显著且同号的分支占比",
     "整体稳健性的一票式判断", "已实现"),
    ("8 空间与分组", "分省回归", "浙江、四川、河南分别回归",
     "结论是否被单一省份驱动", "已实现"),
    ("8 空间与分组", "剔除数据质量较差的省", "浙江+四川合并回归",
     "河南样本缺失严重带来的偏误", "已实现"),
    ("8 空间与分组", "空间自相关检验", "Moran's I 与空间误差模型",
     "相邻县的相互影响", "需县级经纬度或邻接矩阵"),
    ("8 空间与分组", "分位数分组异质性", "按经济水平或人口规模分组",
     "效应在不同发展阶段是否不同", "已实现(分组形式)"),
    ("9 数据质量验证", "口径一致性核查", "核对三省学历分类标签与县级归属规则",
     "合并本身是否引入系统误差", "已实现"),
    ("9 数据质量验证", "被解释变量稳健性", "用「原表标记」与「按原文重判」两套口径分别回归",
     "清洗方式差异对结论的影响", "待 A 表确认口径"),
]


def multiple_testing(df):
    """对稳健性分支的 p 值做 Bonferroni 与 Holm 校正。"""
    work = df.dropna(subset=["p值"]).copy()
    if work.empty:
        return pd.DataFrame()
    m = len(work)
    work = work.sort_values("p值").reset_index(drop=True)
    work["Bonferroni阈值"] = 0.05 / m
    work["Bonferroni是否显著"] = np.where(work["p值"] < 0.05 / m, "是", "否")
    holm_cut = 0.05 / (m - np.arange(m))
    work["Holm临界值"] = holm_cut
    work["Holm是否显著"] = np.where(work["p值"] <= holm_cut, "是", "否")
    return work[["检验类别", "检验名称", "p值", "Bonferroni阈值", "Bonferroni是否显著",
                 "Holm临界值", "Holm是否显著"]]


def stability_summary(df):
    """汇总各分组的系数符号与显著性，作为整体稳健性的判据。"""
    work = df.dropna(subset=["系数"])
    if work.empty:
        return pd.DataFrame()
    work = work.copy()
    work["显著"] = work["p值"].apply(lambda p: "显著" if pd.notna(p) and p < 0.1 else "不显著")
    work["方向"] = np.where(work["系数"] > 0, "正", "负")
    out = work.groupby("检验类别").agg(
        检验数=("系数", "size"),
        正向占比=("方向", lambda s: (s == "正").mean()),
        显著占比=("显著", lambda s: (s == "显著").mean()),
        系数中位数=("系数", "median"),
        系数最小=("系数", "min"),
        系数最大=("系数", "max"),
    ).reset_index()
    return out


def coefficient_plot(df, path):
    """画核心解释变量系数在不同设定下的分布，直观看稳定性。"""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]
        plt.rcParams["axes.unicode_minus"] = False
    except Exception:
        return False

    work = df.dropna(subset=["系数", "标准误"]).copy()
    if work.empty:
        return False
    work = work.sort_values("系数").reset_index(drop=True)
    y_pos = np.arange(len(work))
    fig, ax = plt.subplots(figsize=(9, max(6, 0.28 * len(work))))
    ax.errorbar(work["系数"], y_pos,
                xerr=1.96 * work["标准误"], fmt="o", ms=4, lw=1,
                color="#1f4e79", ecolor="#9bb7d4")
    ax.axvline(0, color="#c00000", lw=1, ls="--")
    base = work[work["检验名称"] == "基准回归"]
    if not base.empty:
        ax.axvline(float(base["系数"].iloc[0]), color="#2e7d32", lw=1, ls=":")
    ax.set_yticks(y_pos)
    ax.set_yticklabels(work["检验名称"], fontsize=7)
    ax.set_xlabel("核心解释变量系数（含 95% 置信区间）")
    ax.set_title("稳健性检验：核心解释变量系数分布")
    ax.grid(axis="x", alpha=0.3)
    fig.tight_layout()
    fig.savefig(path, dpi=180)
    plt.close(fig)
    return True


# ------------------------------------------------------------------ 入口
def add_selfcheck_variables(df):
    """程序自检专用：生成合成解释变量。结果不可用于论文任何部分。"""
    rng = np.random.default_rng(20260926)
    n = len(df)
    out = df.copy()
    out["平均受教育年限"] = np.round(rng.normal(9.4, 0.9, n), 2)
    out["大专及以上人口占比"] = np.round(np.clip(rng.beta(3, 10, n), 0.01, 0.6), 4)
    out["高中及以上人口占比"] = np.round(np.clip(rng.beta(6, 6, n), 0.1, 0.8), 4)
    out["常住人口"] = np.round(np.exp(rng.normal(3.6, 0.8, n)))
    out["人均GDP"] = np.round(np.exp(rng.normal(10.6, 0.4, n)))
    out["二产就业占比"] = np.round(rng.uniform(0.20, 0.55, n), 3)
    out["三产就业占比"] = np.round(rng.uniform(0.25, 0.60, n), 3)
    return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--selfcheck", action="store_true",
                        help="用合成解释变量验证程序，输出到 _程序自检 目录")
    args = parser.parse_args()

    src = OUT / "03_县级招聘侧指标.xlsx"
    if not src.exists():
        print("缺少 03_县级招聘侧指标.xlsx，请先运行 01_build_dataset.py")
        return 1
    county = usable_counties(pd.read_excel(src, sheet_name="县级指标"))

    result_dir = OUT / "程序自检" if args.selfcheck else T3
    result_dir.mkdir(parents=True, exist_ok=True)

    if args.selfcheck:
        data = add_selfcheck_variables(county)
        tag = "程序自检（合成解释变量，结果不可用于论文）"
    else:
        delivered = T3 / "交付1_县级分析数据.xlsx"
        source = delivered if delivered.exists() else OUT / "04_分析数据集.xlsx"
        sheet = "县级分析数据" if delivered.exists() else "分析数据"
        data = usable_counties(pd.read_excel(source, sheet_name=sheet))
        tag = "正式运行"

    roles = resolve_roles(data)
    key = roles.get("人力资本_年限")
    if key is None:
        print("=" * 68)
        print("核心解释变量缺失，程序不编造数据，已停止计量分析。")
        print("需要在 04_分析数据集.xlsx 中补齐下列列（列名含关键词即可）：")
        for role, patterns in ROLE_PATTERNS.items():
            hit = "已找到：" + str(roles[role]) if role in roles else "缺失"
            print(f"  - {role:<10} 关键词 {patterns} → {hit}")
        print("=" * 68)
        return 2

    controls = [roles[r] for r in CONTROL_ORDER if r in roles]
    print(f"[{tag}] 样本：{len(data)} 个县级单位")
    print(f"核心解释变量：{key}")
    print(f"控制变量：{controls if controls else '（暂无）'}")

    results, skipped = run_battery(data, key, controls)
    if results.empty:
        print("没有产生任何可用结果，请检查数据。")
        return 3

    correction = multiple_testing(results)
    summary = stability_summary(results)

    out_xlsx = result_dir / "06_回归结果_基准与稳健性.xlsx"
    with pd.ExcelWriter(out_xlsx, engine="openpyxl") as writer:
        results.to_excel(writer, sheet_name="全部检验", index=False)
        summary.to_excel(writer, sheet_name="稳健性汇总", index=False)
        if not correction.empty:
            correction.to_excel(writer, sheet_name="多重检验校正", index=False)
        if not skipped.empty:
            skipped.to_excel(writer, sheet_name="未执行清单", index=False)
        pd.DataFrame({
            "项目": ["数据来源", "样本量", "核心解释变量", "控制变量", "运行模式"],
            "内容": [src.name, len(data), key, "、".join(controls) or "无", tag],
        }).to_excel(writer, sheet_name="运行说明", index=False)

    check = pd.DataFrame(CHECKLIST, columns=["检验类别", "检验名称", "做法", "要回答的问题", "状态"])
    # 检验清单是正式交付物，无论是否自检都写到成果根目录
    check.to_excel(OUT / "06_稳健性检验清单.xlsx", index=False, sheet_name="清单")

    plotted = coefficient_plot(results, result_dir / "08_系数稳定性图.png")

    print()
    print(summary.to_string(index=False))
    print()
    print(f"共 {len(results)} 条检验结果，{len(skipped)} 条未执行。")
    print("系数稳定性图：", "已输出" if plotted else "未输出（缺 matplotlib）")
    print("结果文件：", out_xlsx)
    return 0


if __name__ == "__main__":
    sys.exit(main())
