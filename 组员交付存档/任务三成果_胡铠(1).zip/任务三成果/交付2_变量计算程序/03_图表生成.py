# -*- coding: utf-8 -*-
"""生成任务三成果报告所需的图表，并校验中文字形是否齐全。"""
import sys
import warnings
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(r"D:\大创不自信版")
T3 = ROOT / "任务三成果"
ATTACH = T3 / "附件"
OUT = ATTACH / "图表"
OUT.mkdir(parents=True, exist_ok=True)

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["figure.dpi"] = 200

TEXT_COLOR = "#000000"
LINE = ["#1f4e79", "#8c8c8c", "#c00000", "#7f9db9"]

detail = pd.read_excel(ATTACH / "02_招聘明细_清洗版.xlsx", sheet_name="清洗明细")
county = pd.read_excel(ATTACH / "03_县级招聘侧指标.xlsx", sheet_name="县级指标")
county = county[county["县区"] != "未归属县区"]

ORDER = ["未注明", "学历不限", "初中及以下", "高中及以上", "大专及以上", "本科及以上", "硕士及以上"]
PROVINCES = ["浙江", "四川", "河南"]


def save(fig, name):
    path = OUT / name
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        fig.tight_layout()
        fig.savefig(path, dpi=200, facecolor="white")
    plt.close(fig)
    missing = [str(w.message) for w in caught if "missing from font" in str(w.message)]
    print(f"  {name}: {'字形齐全' if not missing else '缺字形 → ' + str(missing[:3])}")
    return path


def chart_structure():
    share = (pd.crosstab(detail["省"], detail["学历门槛"], normalize="index")
             .reindex(index=PROVINCES, columns=ORDER).fillna(0))
    fig, ax = plt.subplots(figsize=(6.0, 2.9))
    bottom = np.zeros(len(share))
    colors = ["#d9d9d9", "#bfbfbf", "#8c8c8c", "#7f9db9", "#4a7ba7", "#1f4e79", "#0f2f4a"]
    for label, color in zip(ORDER, colors):
        values = share[label].values * 100
        ax.bar(share.index, values, bottom=bottom, label=label, color=color,
               edgecolor="white", linewidth=0.6)
        for x, (v, b) in enumerate(zip(values, bottom)):
            if v >= 6:
                ax.text(x, b + v / 2, f"{v:.1f}", ha="center", va="center",
                        fontsize=7, color="white" if label in ORDER[3:] else "#333333")
        bottom += values
    ax.set_ylabel("占本省招聘广告的比例（%）", fontsize=8.5, color=TEXT_COLOR)
    ax.tick_params(labelsize=8.5, colors=TEXT_COLOR)
    ax.set_ylim(0, 100)
    ax.legend(fontsize=7, ncol=4, loc="upper center", bbox_to_anchor=(0.5, -0.16),
              frameon=False)
    for spine in ("top", "right"):
        ax.spines[spine].set_visible(False)
    return save(fig, "图1_三省招聘广告学历门槛结构.png")


def chart_distribution():
    data = [county.loc[county["省"] == p, "大专及以上占比"].values * 100 for p in PROVINCES]
    fig, ax = plt.subplots(figsize=(6.0, 2.7))
    bp = ax.boxplot(data, tick_labels=PROVINCES, widths=0.5, patch_artist=True,
                    medianprops=dict(color="#c00000", linewidth=1.4),
                    boxprops=dict(facecolor="#dce6f1", edgecolor="#1f4e79"),
                    whiskerprops=dict(color="#1f4e79"),
                    capprops=dict(color="#1f4e79"),
                    flierprops=dict(marker="o", markersize=3, markerfacecolor="#8c8c8c",
                                    markeredgecolor="#8c8c8c"))
    for i, values in enumerate(data, start=1):
        jitter = np.random.default_rng(7).normal(0, 0.045, len(values))
        ax.plot(np.full(len(values), i) + jitter, values, ".", color="#1f4e79",
                alpha=0.35, markersize=3.5)
    ax.set_ylabel("要求大专及以上的广告占比（%）", fontsize=8.5, color=TEXT_COLOR)
    ax.tick_params(labelsize=8.5, colors=TEXT_COLOR)
    ax.grid(axis="y", alpha=0.25)
    for spine in ("top", "right"):
        ax.spines[spine].set_visible(False)
    return save(fig, "图2_县级学历门槛需求分布.png")


def chart_wage():
    order = ["初中及以下", "中专/中技", "高中", "学历不限", "大专", "本科", "硕士", "博士"]
    zj = detail[detail["省"] == "浙江"]
    stat = (zj.groupby("学历要求原文")["月薪中值"]
            .agg(["median", "size"]).reindex(order).dropna())
    fig, ax = plt.subplots(figsize=(6.0, 2.6))
    bars = ax.barh(stat.index, stat["median"], color="#4a7ba7", height=0.6)
    for bar, (value, n) in zip(bars, zip(stat["median"], stat["size"])):
        ax.text(value + 250, bar.get_y() + bar.get_height() / 2,
                f"{value:,.0f}（n={int(n)}）", va="center", fontsize=7.5, color=TEXT_COLOR)
    ax.set_xlabel("月薪中位数（元）", fontsize=8.5, color=TEXT_COLOR)
    ax.tick_params(labelsize=8.5, colors=TEXT_COLOR)
    ax.set_xlim(0, stat["median"].max() * 1.35)
    ax.grid(axis="x", alpha=0.25)
    for spine in ("top", "right"):
        ax.spines[spine].set_visible(False)
    return save(fig, "图3_浙江学历与薪资梯度.png")


if __name__ == "__main__":
    print("生成图表：")
    for fn in (chart_structure, chart_distribution, chart_wage):
        fn()
    print("输出目录:", OUT)
