# -*- coding: utf-8 -*-
"""优化设定：样本收缩到浙江与四川，并在地级市层面重新估计。"""

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm

ROOT = Path(r"D:\大创不自信版")
T3 = ROOT / "任务三成果"


def fit(data, y, x, controls, fe=None, cluster=None, weights=None, cov="HC1"):
    used = [y, x] + list(controls) + ([fe] if fe else []) + ([cluster] if cluster else []) + \
           ([weights] if weights else [])
    d = data[used].dropna().copy()
    if len(d) < 15:
        return None
    Y = d[y].astype(float).values
    X = d[[x] + list(controls)].astype(float)
    if fe:
        X = pd.concat([X, pd.get_dummies(d[fe].astype(str), prefix=fe,
                                         drop_first=True).astype(float)], axis=1)
    X = sm.add_constant(X, has_constant="add")
    m = sm.WLS(Y, X, weights=d[weights].astype(float)) if weights else sm.OLS(Y, X)
    if cluster:
        r = m.fit(cov_type="cluster", cov_kwds={"groups": d[cluster].astype(str).values})
    else:
        r = m.fit(cov_type=cov)
    return {"coef": float(r.params[x]), "se": float(r.bse[x]), "p": float(r.pvalues[x]),
            "n": int(r.nobs), "r2": float(r.rsquared)}


def row(label, r, note=""):
    if r is None:
        return [label, "—", "—", "—", "—", "—", note]
    return [label, f"{r['coef']:.3f}", f"{r['se']:.3f}",
            "<0.001" if r["p"] < 0.001 else f"{r['p']:.3f}",
            f"{r['n']}", f"{r['r2']:.3f}", note]


def main():
    d = pd.read_excel(T3 / "交付1_县级分析数据.xlsx", sheet_name="县级分析数据")
    d = d[d["纳入基准样本"] == 1].copy()
    C = ["常住人口对数", "人均GDP对数", "二产占比", "三产占比"]
    east = d[d["省"].isin(["浙江", "四川"])].copy()

    print("样本：全样本 %d，浙江+四川 %d（浙江 %d，四川 %d）"
          % (len(d), len(east), (east["省"] == "浙江").sum(), (east["省"] == "四川").sum()))
    print()

    rows = [["设定", "系数", "标准误", "p 值", "样本量", "R²", "说明"]]
    rows.append(row("浙+川·基准（全控制·HC1）", fit(east, "大专及以上占比", "平均受教育年限", C)))
    rows.append(row("浙+川·聚类到地级市",
                    fit(east, "大专及以上占比", "平均受教育年限", C, cluster="地级市"),
                    "允许同市扰动项相关"))
    rows.append(row("浙+川·地级市固定效应",
                    fit(east, "大专及以上占比", "平均受教育年限", C, fe="地级市"),
                    "只使用市内的县际差异"))
    rows.append(row("浙+川·仅县与县级市",
                    fit(east[east["行政级别"] != "市辖区"], "大专及以上占比",
                        "平均受教育年限", C)))
    rows.append(row("浙+川·广告数≥50",
                    fit(east[east["广告数"] >= 50], "大专及以上占比",
                        "平均受教育年限", C)))
    rows.append(row("浙+川·被解释变量改本科及以上",
                    fit(east, "本科及以上占比", "平均受教育年限", C)))
    rows.append(row("浙+川·核心变量改大专以上人口占比",
                    fit(east, "大专及以上占比", "大专及以上人口占比", C)))
    rows.append(row("浙+川·按广告数加权",
                    fit(east, "大专及以上占比", "平均受教育年限", C, weights="广告数")))

    # 地级市层面：先按广告数加权汇总到市，再回归
    g = east.groupby(["省", "地级市"]).apply(
        lambda s: pd.Series({
            "大专及以上占比": np.average(s["大专及以上占比"], weights=s["广告数"]),
            "本科及以上占比": np.average(s["本科及以上占比"], weights=s["广告数"]),
            "平均受教育年限": np.average(s["平均受教育年限"], weights=s["pop_total_2020"]),
            "大专及以上人口占比": np.average(s["大专及以上人口占比"],
                                     weights=s["pop_total_2020"]),
            "常住人口对数": np.log(s["pop_total_2020"].sum()),
            "人均GDP对数": np.average(s["人均GDP对数"], weights=s["pop_total_2020"]),
            "二产占比": np.average(s["二产占比"], weights=s["gdp_wanyuan_2020"]),
            "三产占比": np.average(s["三产占比"], weights=s["gdp_wanyuan_2020"]),
            "广告数": s["广告数"].sum(),
        }), include_groups=False).reset_index()
    print("地级市层面样本：%d 个市" % len(g))
    rows.append(row("地级市层面·基准", fit(g, "大专及以上占比", "平均受教育年限", C),
                    "市为观测单位，广告数加权汇总"))
    rows.append(row("地级市层面·被解释变量改本科及以上",
                    fit(g, "本科及以上占比", "平均受教育年限", C)))
    rows.append(row("地级市层面·核心变量改大专以上人口占比",
                    fit(g, "大专及以上占比", "大专及以上人口占比", C)))

    out = pd.DataFrame(rows[1:], columns=rows[0])
    print()
    print(out.to_string(index=False))
    out.to_pickle(T3 / "_refined.pkl")

    print()
    print("浙+川组内相关：", round(np.corrcoef(
        east["平均受教育年限"], east["大专及以上占比"])[0, 1], 3),
        "| 地级市去均值后：", round(np.corrcoef(
            east["平均受教育年限"] - east.groupby("地级市")["平均受教育年限"].transform("mean"),
            east["大专及以上占比"] - east.groupby("地级市")["大专及以上占比"].transform("mean")
        )[0, 1], 3))


if __name__ == "__main__":
    main()
